import xlwt

from file.exceldata.exceldata import ExcelData
from file.resourcemanager.resourcemanger import ResourcePath
from file.student.student import Student
from file.excelformat.excelformat import ExcelFormat

studentsCollection = []


"""
    填写excel信息，调用getPhoto,如果返回值为none
    高亮那个单元格
    填写完调用addToCollection方法
"""


def fillIn():
    path = ResourcePath("学生信息.xlsx", True)
    excel = ExcelData(path)
    format = ExcelFormat(path)
    firstCol = excel.getColsContent(0)
    secondCol = excel.getColsContent(1)
    for i in range(0, len(firstCol)):
        information = None
        studentPath = int(secondCol[i]).__str__() + "/" + int(secondCol[i]).__str__() + ".jpg"
        if ResourcePath(studentPath, False).isExist():
            format.setCellValue(i + 2, 3, studentPath)
            information = ResourcePath(studentPath, True)
        else:
            format.setBackgroundColor(i + 2, 3)
        format.save()
        addToCollection(firstCol[i], int(secondCol[i]), information)


"""
     @:param 学生学号
     查找学生学号对应的photo路径**
     不存在返回none
"""


def getPhotoPath(num):
    for student in studentsCollection:
        if student.getNumber() == num:
            return student.getPhotoInformation()


def getPhotoPath(name):
    for student in studentsCollection:
        if student.getName() == name:
            return student.getPhotoInformation()

"""
        @:param学生各项信息
        @:Nullable photoInformation可为空值
        新建student对象
        同时放入studentCollection中
"""


def addToCollection(name, num, photoInformation):
    student = Student(name, num, photoInformation)
    studentsCollection.append(student)

