import openpyxl
from openpyxl.styles import PatternFill
from file.resourcemanager.resourcemanger import ResourcePath


class ExcelFormat:

    def __init__(self, path):
        if not isinstance(path, ResourcePath):
            raise AttributeError()
        self.path = path
        self.table = openpyxl.load_workbook(self.path.getPath())
        self.sheet = self.table.worksheets[0]

    def getCell(self, row, col):
        return self.sheet.cell(row, col)

    def setCellValue(self, row, col, value):
        self.sheet.cell(row, col).value = value

    def setBackgroundColor(self, row, col):
        pattern = PatternFill("solid", "FFFF00")
        self.getCell(row, col).fill = pattern

    def save(self):
        self.table.save("学生信息改.xlsx")
