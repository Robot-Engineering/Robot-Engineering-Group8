from file.resourcemanager.resourcemanger import *


class Student:

    def __init__(self, name, number, photoInformation):
        self.__name = name
        self.__number = number
        if photoInformation is not None:
            assert isinstance(photoInformation, ResourcePath)
        self.__photoInformation = photoInformation

    def setName(self, name):
        self.__name = name

    def getName(self):
        return self.__name

    def setNumber(self, number):
        self.__number = number

    def getNumber(self):
        return self.__number

    def setPhotoInformation(self, path):
        assert isinstance(path, ResourcePath)
        self.__photoInformation = path

    def getPhotoInformation(self):
        return self.__photoInformation

