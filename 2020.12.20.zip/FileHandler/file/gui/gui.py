import tkinter
from tkinter import ttk
from PIL import Image, ImageTk

from file.filehanlder import filehandler

filehandler.fillIn()


def getValues():
    values = []
    for student in filehandler.studentsCollection:
        value = student.getName() + "(" + str(student.getNumber()) + ")"
        values.append(value)
    return values


class Screen:

    def __init__(self, width, height):
        self.__window = tkinter.Tk()
        self.__width = width
        self.__height = height
        self.__x = (self.__window.winfo_screenwidth() - width) / 2
        self.__y = (self.__window.winfo_screenheight() - height) / 2
        attribute = '%dx%d+%d+%d' % (self.__width, self.__height, self.__x, self.__y)
        self.__window.geometry(attribute)

    def show(self):
        self.__window.mainloop()

    def getWindow(self):
        return self.__window


class StudentGui(Screen):

    def __init__(self, width, height):
        super().__init__(width, height)

    def onSelect(self, listChosen):
        name = str(listChosen.get()).split("(")[0]
        image = tkinter.PhotoImage( filehandler.getPhotoPath(name).getPath())
        photo = tkinter.Label()

    def addListBox(self):
        tkinter.StringVar()
        listChosen = ttk.Combobox()
        listChosen["values"] = tuple(getValues())
        listChosen.current(0)
        listChosen.bind("<<ComboboxSelected>>", self.onSelect(listChosen))
        listChosen.pack()


gui = StudentGui(200, 300)
gui.addListBox()
gui.show()
