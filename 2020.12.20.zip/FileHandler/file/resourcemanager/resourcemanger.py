import os


def getResourcePath():
    resourcePath = os.getcwd()
    while os.path.basename(resourcePath) != "FileHandler":
        resourcePath = os.path.abspath(os.path.join(resourcePath, os.path.pardir))
    resourcePath = resourcePath + "\\resource"
    os.chdir(resourcePath)
    return resourcePath


class ResourcePath:

    """
        @:param simulate是否检测文件是否存在
    """

    def __init__(self, path, simulate):
        simulatePath = getResourcePath() + "\\" + path
        if simulate:
            if not os.path.exists(path):
                raise AttributeError(simulatePath + "文件不存在")
        self.__path = simulatePath

    def getPath(self):
        return self.__path

    def setPath(self, path):
        self.__path = getResourcePath() + "\\" + path

    def isExist(self):
        return os.path.exists(self.__path)

