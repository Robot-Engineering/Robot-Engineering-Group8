from robotproject.robotmysql import *

initRobotTable()
initRobotOrderTable()


