import pymysql

"""
    利用sql语句就行建表
"""

host = '127.0.0.1'
user = 'root'
passwd = 'root'
port = 3306
robotDb = 'robot_order'


def showRobotOrder():
    return "SELECT * FROM robot_order"


def initRobotOrderTable():
    connection = pymysql.connect(host=host, user=user, passwd=passwd, port=port, db=robotDb)
    cursor = connection.cursor()
    sql = "create table robot_order(id int auto_increment primary key,account varchar(32),goods varchar(32)," \
          "money int,create_time datetime,payment_time datetime, arrival_time datetime, robot_id int)engine=INNODB " \
          "default charset=utf8; "
    cursor.execute(sql)
    connection.commit()
    cursor.close()
    connection.close()


def initRobotTable():
    connection = pymysql.connect(host=host, user=user, passwd=passwd, port=port, db=robotDb)
    cursor = connection.cursor()
    sql = "create table robot_order(id int auto_increment primary key,type varchar(32),total_power int," \
          "portable_package int)engine=INNODB default charset=utf8; "
    cursor.execute(sql)
    connection.commit()
    cursor.close()
    connection.close()


