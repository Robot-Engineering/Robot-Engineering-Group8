from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, ForeignKey, UniqueConstraint, Index
from sqlalchemy.orm import sessionmaker, relationship
from sqlalchemy import create_engine

engine = create_engine("mysql+pymysql://root:root@127.0.0.1:3306/robot_order", max_overflow=5)

Base = declarative_base()


def init_db():
    Base.metadata.create_all(engine)


class RobotOrder(Base):

    __tablename__ = "robot_order"
    uuid = Column(Integer, primary_key=True, autoincrement=True)
    robot_uuid = Column(Integer)
    account = Column(String(20))
    money = Column(Integer)
    goods = Column(String(20))
    create_time = Column(Integer)
    payment_time = Column(Integer)
    arrival_time = Column(Integer)


DBSession = sessionmaker(bind=engine)

init_db()