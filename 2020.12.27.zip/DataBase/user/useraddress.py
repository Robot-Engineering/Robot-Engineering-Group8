from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, ForeignKey, UniqueConstraint, Index
from sqlalchemy.orm import sessionmaker, relationship
from sqlalchemy import create_engine


engine = create_engine("mysql+pymysql://root:root@127.0.0.1:3306/robot_order", max_overflow=5)

Base = declarative_base()


def init_db():
    Base.metadata.create_all(engine)


class UserAddressInformation(Base):

    __tablename__ = "user_address"
    account = Column(String(20), primary_key=True)
    name = Column(String(20))
    city = Column(String(20))
    region = Column(String(20))
    detailedAddress = Column(String(20))


DBSession = sessionmaker(bind=engine)
init_db()
Session = sessionmaker()
Session.configure(bind=engine)
session = Session()


def addUserAddress(account, name, city, region, detailedAddress):
    user = UserAddressInformation(account=account, name=name, city=city, region=region, detailedAddress=detailedAddress)
    session.add(user)
    session.commit()


def deleteUserAddress(account):
    session.query(UserAddressInformation).filter(UserAddressInformation.account == account).delete()
    session.commit()


def updateUserAddress(account, name):
    session.query(UserAddressInformation).filter(UserAddressInformation.account == account).update({"name": name})
    session.commit()


def updateUserAddress(account, city):
    session.query(UserAddressInformation).filter(UserAddressInformation.account == account).update({"city": city})
    session.commit()


def updateUserAddress(account, region):
    session.query(UserAddressInformation).filter(UserAddressInformation.account == account).update({"region": region})
    session.commit()


def updateUserAddress(account, detailedAddress):
    session.query(UserAddressInformation).filter(UserAddressInformation.account == account).update({"detailedAddress": detailedAddress})
    session.commit()


def getAllUserAddresses():
    return session.query(UserAddressInformation).all()


def getUserAddress(account):
    return session.query(UserAddressInformation).filter(UserAddressInformation.account == account).one()


def getUserAddress(name):
    return session.query(UserAddressInformation).filter(UserAddressInformation.name == name).one()
